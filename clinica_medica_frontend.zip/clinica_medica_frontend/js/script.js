document.addEventListener('DOMContentLoaded', () => {
    // --- Lógica de Navegação entre Seções ---
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link, .btn[data-section]');
    const pageSections = document.querySelectorAll('.page-section');
    const navbarCollapse = document.getElementById('navbarNav'); // Para fechar o menu no mobile

    function showSection(sectionId) {
        // Esconde todas as seções
        pageSections.forEach(section => {
            section.classList.remove('active');
            section.classList.add('d-none');
        });

        // Mostra a seção desejada
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            targetSection.classList.remove('d-none');
        }

        // Atualiza a classe 'active' na navbar
        navLinks.forEach(link => {
            link.classList.remove('active');
            link.removeAttribute('aria-current');
        });

        const activeNavLink = document.querySelector(`.navbar-nav .nav-link[data-section="${sectionId}"]`);
        if (activeNavLink) {
            activeNavLink.classList.add('active');
            activeNavLink.setAttribute('aria-current', 'page');
        }

        // Fecha o menu hamburguer no mobile
        if (navbarCollapse && navbarCollapse.classList.contains('show')) {
            let bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
            if (!bsCollapse) {
                bsCollapse = new bootstrap.Collapse(navbarCollapse, { toggle: false });
            }
            bsCollapse.hide();
        }
    }

    // Evento de clique para navegação
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const sectionId = link.dataset.section;
            if (sectionId) {
                showSection(sectionId);
            }
        });
    });

    // --- Lógica de Login e Persistência ---
    const loginForm = document.getElementById('loginForm');
    const loginModalEl = document.getElementById('loginModal');
    const loginModal = loginModalEl ? new bootstrap.Modal(loginModalEl) : null;
    const navLogin = document.getElementById('navLogin');
    const navUserMenu = document.getElementById('navUserMenu');
    const loggedInUserNameSpan = document.getElementById('loggedInUserName');
    const logoutBtn = document.getElementById('logoutBtn');
    const dashboardUserName = document.getElementById('dashboardUserName');
    const dashboardUserEmail = document.getElementById('dashboardUserEmail');

    const TEST_USER = {
        email: 'test@example.com',
        password: 'password123',
        name: 'Paciente Exemplo'
    };

    function setLoggedInUser(user) {
        localStorage.setItem('loggedInUser', JSON.stringify(user));
        updateUIForLogin(user);
    }

    function getLoggedInUser() {
        const user = localStorage.getItem('loggedInUser');
        return user ? JSON.parse(user) : null;
    }

    function removeLoggedInUser() {
        localStorage.removeItem('loggedInUser');
        updateUIForLogin(null);
    }

    function updateUIForLogin(user) {
        if (user) {
            navLogin?.classList.add('d-none');
            navUserMenu?.classList.remove('d-none');
            if (loggedInUserNameSpan) loggedInUserNameSpan.textContent = user.name;
            if (dashboardUserName) dashboardUserName.textContent = user.name;
            if (dashboardUserEmail) dashboardUserEmail.textContent = user.email;
        } else {
            navLogin?.classList.remove('d-none');
            navUserMenu?.classList.add('d-none');
            if (loggedInUserNameSpan) loggedInUserNameSpan.textContent = '';
            if (dashboardUserName) dashboardUserName.textContent = '';
            if (dashboardUserEmail) dashboardUserEmail.textContent = '';
            const dashboardSection = document.getElementById('dashboard');
            if (dashboardSection && dashboardSection.classList.contains('active')) {
                showSection('home');
            }
        }
    }

    const currentUser = getLoggedInUser();
    updateUIForLogin(currentUser);

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail')?.value;
            const password = document.getElementById('loginPassword')?.value;
            const rememberMe = document.getElementById('rememberMe')?.checked;

            if (email === TEST_USER.email && password === TEST_USER.password) {
                const userToStore = {
                    email: TEST_USER.email,
                    name: TEST_USER.name,
                    rememberMe: rememberMe
                };

                if (rememberMe) {
                    setLoggedInUser(userToStore);
                } else {
                    updateUIForLogin(userToStore);
                }

                loginModal?.hide();
                alert('Login realizado com sucesso!');
                showSection('dashboard');
            } else {
                alert('E-mail ou senha incorretos.');
            }
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            removeLoggedInUser();
            alert('Você foi desconectado.');
            showSection('home');
        });
    }

    // --- Lógica do Formulário de Agendamento ---
    const appointmentForm = document.getElementById('appointmentForm');

    if (appointmentForm) {
        appointmentForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const patientName = document.getElementById('patientName')?.value;
            const serviceSelect = document.getElementById('serviceSelect')?.value;
            const preferredDate = document.getElementById('preferredDate')?.value;

            alert(`Solicitação de agendamento recebida!\n\nNome: ${patientName}\nServiço: ${serviceSelect}\nData Preferencial: ${preferredDate}\n\nEntraremos em contato para confirmar.`);
            appointmentForm.reset();
            showSection('home');
        });
    }

    // Inicia na seção Home
    showSection('home');
});
